"""
Predictive Modeling Using Machine Learning
------------------------------------------
Task: predict whether a breast tumour is malignant or benign from 30 measured features.
Algorithms: Logistic Regression, Decision Tree, Random Forest
Evaluation: accuracy, precision, recall, F1, ROC-AUC, confusion matrices, ROC curves,
            5-fold cross-validation, feature importance.
"""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (accuracy_score, precision_score, recall_score, f1_score,
                             roc_auc_score, roc_curve, confusion_matrix,
                             ConfusionMatrixDisplay, classification_report)

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs")
os.makedirs(OUT, exist_ok=True)
SEED = 42

# 1. Load data -------------------------------------------------------------
data = load_breast_cancer(as_frame=True)
X, y = data.data, data.target          # target: 0 = malignant, 1 = benign
print(f"Dataset: {X.shape[0]} samples, {X.shape[1]} features")
print("Class balance:\n", y.value_counts().rename({0: "malignant", 1: "benign"}), "\n")
print("Missing values:", int(X.isna().sum().sum()), "\n")

# 2. Train / test split (stratified keeps class ratio) ---------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=SEED, stratify=y)

# 3. Models ----------------------------------------------------------------
models = {
    "Logistic Regression": make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000)),
    "Decision Tree": DecisionTreeClassifier(max_depth=4, random_state=SEED),
    "Random Forest": RandomForestClassifier(n_estimators=300, random_state=SEED),
}

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)
results, probs, preds = [], {}, {}

for name, model in models.items():
    cv_acc = cross_val_score(model, X_train, y_train, cv=cv, scoring="accuracy")
    model.fit(X_train, y_train)
    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]
    preds[name], probs[name] = y_pred, y_prob
    results.append({
        "Model": name,
        "CV Accuracy (mean)": cv_acc.mean(),
        "Test Accuracy": accuracy_score(y_test, y_pred),
        "Precision": precision_score(y_test, y_pred),
        "Recall": recall_score(y_test, y_pred),
        "F1": f1_score(y_test, y_pred),
        "ROC-AUC": roc_auc_score(y_test, y_prob),
    })

res = pd.DataFrame(results).set_index("Model").round(4)
print("=== Model comparison ===")
print(res.to_string(), "\n")
res.to_csv(f"{OUT}/model_comparison.csv")

best = res["ROC-AUC"].idxmax()
print(f"Best model by ROC-AUC: {best}\n")
print(f"Classification report ({best}):")
print(classification_report(y_test, preds[best], target_names=["malignant", "benign"]))

# 4. Confusion matrices ----------------------------------------------------
fig, axes = plt.subplots(1, 3, figsize=(15, 4.5))
for ax, (name, y_pred) in zip(axes, preds.items()):
    cm = confusion_matrix(y_test, y_pred)
    ConfusionMatrixDisplay(cm, display_labels=["malignant", "benign"]).plot(
        ax=ax, cmap="Blues", colorbar=False)
    ax.set_title(f"{name}\nAccuracy = {accuracy_score(y_test, y_pred):.3f}")
plt.tight_layout()
plt.savefig(f"{OUT}/confusion_matrices.png", dpi=150)
plt.close()

# 5. ROC curves ------------------------------------------------------------
plt.figure(figsize=(6.5, 5.5))
for name, y_prob in probs.items():
    fpr, tpr, _ = roc_curve(y_test, y_prob)
    plt.plot(fpr, tpr, lw=2, label=f"{name} (AUC = {roc_auc_score(y_test, y_prob):.3f})")
plt.plot([0, 1], [0, 1], "k--", lw=1, label="Chance")
plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curves – Test Set")
plt.legend(loc="lower right")
plt.grid(alpha=0.3)
plt.tight_layout()
plt.savefig(f"{OUT}/roc_curves.png", dpi=150)
plt.close()

# 6. Feature importance (Random Forest) -----------------------------------
rf = models["Random Forest"]
imp = pd.Series(rf.feature_importances_, index=X.columns).sort_values().tail(10)
plt.figure(figsize=(7, 5))
imp.plot(kind="barh", color="#3b7dd8")
plt.title("Top 10 Feature Importances – Random Forest")
plt.xlabel("Importance")
plt.tight_layout()
plt.savefig(f"{OUT}/feature_importance.png", dpi=150)
plt.close()

print("Top 5 features:", list(imp.index[::-1][:5]))
print("\nSaved: model_comparison.csv, confusion_matrices.png, roc_curves.png, feature_importance.png")
