# Predictive Modeling Using Machine Learning

Supervised-learning project that predicts whether a breast tumour is **malignant or benign**
using scikit-learn's built-in Breast Cancer Wisconsin dataset (569 samples, 30 features).

## Algorithms
- Logistic Regression (with standard scaling)
- Decision Tree (max depth 4)
- Random Forest (300 trees)

## Method
1. Load data and check class balance / missing values
2. Stratified 80/20 train-test split
3. 5-fold cross-validation on the training set
4. Evaluate on the held-out test set: accuracy, precision, recall, F1, ROC-AUC
5. Visualise confusion matrices, ROC curves and feature importance

## Results (test set)

| Model | CV Acc. | Test Acc. | Precision | Recall | F1 | ROC-AUC |
|---|---|---|---|---|---|---|
| Logistic Regression | 0.978 | 0.983 | 0.986 | 0.986 | 0.986 | 0.995 |
| Decision Tree | 0.930 | 0.939 | 0.958 | 0.944 | 0.951 | 0.934 |
| Random Forest | 0.965 | 0.947 | 0.958 | 0.958 | 0.958 | 0.994 |

Logistic Regression performed best. Top Random Forest features: worst perimeter, worst area,
worst concave points, mean concave points, worst radius.

## Visuals
![Confusion matrices](outputs/confusion_matrices.png)
![ROC curves](outputs/roc_curves.png)
![Feature importance](outputs/feature_importance.png)

## Run it
```bash
pip install -r requirements.txt
python predictive_modeling.py
```
Plots and metrics are written to the `outputs/` folder.

## Structure
```
predictive-modeling-ml/
├── predictive_modeling.py
├── requirements.txt
├── README.md
├── .gitignore
└── outputs/
    ├── confusion_matrices.png
    ├── roc_curves.png
    ├── feature_importance.png
    ├── model_comparison.csv
    └── results.txt
```
